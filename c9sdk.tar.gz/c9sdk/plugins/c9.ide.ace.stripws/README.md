# c9.ide.ace.stripws
